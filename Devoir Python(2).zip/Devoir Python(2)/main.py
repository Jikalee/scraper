import requests
from bs4 import BeautifulSoup
import csv

url = 'https://lenouvelliste.com'  # L'URL du site web
response = requests.get(url)
soup = BeautifulSoup(response.content, 'html.parser')

# Utilisez les sélecteurs CSS appropriés selon la structure HTML fournie
article_elements = soup.select('.lnv-recent-article, .lnv-featured-article-lg')

with open('articles.csv', 'w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerow(['Title', 'Link', 'Image', 'Description'])

    for article in article_elements:
        title = article.select_one('h1').get_text(strip=True) if article.select_one('h1') else 'N/A'
        link = url + article.find_parent('a')['href'] if article.find_parent('a') else 'N/A'
        image = article.select_one('.img-div img')['src'] if article.select_one('.img-div img') else 'N/A'
        description = article.select_one('p').get_text(strip=True) if article.select_one('p') else 'N/A'

        writer.writerow([title, link, image, description])
